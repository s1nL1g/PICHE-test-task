# Test Automation Project

This project demonstrates automated testing of web applications using Selenide, Maven, and TestNG.

## Requirements

Before starting, ensure your computer meets the following requirements:

1. **Java**:
    - Java Development Kit (JDK) version 20 or higher must be installed.
    - Verify the installed Java version with:
      ```bash
      java -version
      ```
    - Download JDK from [Oracle](https://www.oracle.com/java/technologies/javase-downloads.html) or [AdoptOpenJDK](https://adoptopenjdk.net/).

2. **Maven**:
    - Apache Maven version 3.8.x or higher must be installed.
    - Verify the installed Maven version with:
      ```bash
      mvn -version
      ```
    - Download Maven from [Apache Maven](https://maven.apache.org/download.cgi).

3. **Browsers**:
    - Google Chrome must be installed on your machine for running the tests.

4. **Project Archive**:
    - The project is provided as a ZIP archive. Extract it to any folder on your computer.

## Project Structure

- **`src/main`**: Main files (if applicable).
- **`src/test`**: Test classes.
- **`pom.xml`**: Maven configuration file.
- **`suite.xml`**: TestNG configuration file for running tests.

The project includes two test suites in the `suite.xml` file:
- **UI Test**: Validates the user interface of the application.
- **API Test**: Verifies the API functionality.

## Setup

### 1. Extract the Archive
Extract the provided ZIP file to any folder on your computer.

### 2. Verify JDK and Maven
Ensure JDK and Maven are properly installed and accessible from the terminal.

### 3. Download Dependencies
Navigate to the project's root folder (where `pom.xml` is located) and run:
```bash
mvn clean install
```
### 4. Run Tests
To run the tests, execute the following command:
``` bash
mvn -DsuiteXmlFile=suite.xml -P chrome,headlessFalse test
```

## Notes
 - The command specifies the `suite.xml` file for TestNG and enables specific profiles (e.g., `chrome` browser and `headlessFalse` mode).
 - Ensure all dependencies are successfully downloaded during the `mvn clean install` step before running the tests.
