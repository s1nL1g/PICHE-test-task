package tests.ui;

import com.codeborne.selenide.Condition;
import org.testng.annotations.Test;
import pages.HomePage;
import tests.TestInit;

public class TestTitle extends TestInit {

    @Test
    public void checkTitle() {
        HomePage homePage = new HomePage();

        homePage.getTitle().shouldHave(Condition.exactOwnText("Example Domain"));
    }
}