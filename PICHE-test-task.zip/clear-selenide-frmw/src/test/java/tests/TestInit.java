package tests;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Screenshots;
import com.codeborne.selenide.WebDriverRunner;
import io.qameta.allure.Attachment;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import utils.SuiteConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Objects;

import static com.codeborne.selenide.Selenide.open;

public class TestInit {

    private String browser;
    private String headless;

    @BeforeSuite
    public void setParam() throws IOException {
        SuiteConfiguration conf = new SuiteConfiguration();
        browser = conf.getProperty("browser");
        headless = conf.getProperty("headless");
    }

    @BeforeMethod
    public void setup() {
        Configuration.headless = Boolean.parseBoolean(headless);

        if(Boolean.parseBoolean(headless)) {
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("--headless");
            chromeOptions.addArguments("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

            WebDriver driver = new ChromeDriver(chromeOptions);

            WebDriverRunner.setWebDriver(driver);
        }

        open("https://example.com");

        if(!Boolean.parseBoolean(headless)) {
            WebDriverRunner.getWebDriver().manage().window().maximize();
        }
    }

    @AfterMethod
    public void closeBrowser(ITestResult result) {
        WebDriverRunner.getWebDriver().quit();
    }

    public void reloadPage() {
        WebDriverRunner.getWebDriver().navigate().refresh();
    }
}
