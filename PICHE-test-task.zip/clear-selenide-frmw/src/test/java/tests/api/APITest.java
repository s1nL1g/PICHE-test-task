package tests.api;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import tests.api.pojo.CreatePost;
import tests.api.pojo.Post;
import tests.api.spec.Specification;

import static io.restassured.RestAssured.given;

public class APITest {

    @Test(description = "Validate GET request for post with ID 1")
    public void testGetPost() {
        Specification.installSpecification(Specification.requestSpecification(""),
                Specification.responseSpecification(200));

        Post post = given()
                .get("/posts/1")
                .then()
                .log().body()
                .extract().as(Post.class);

        Assert.assertEquals(post.getUserId(), 1);
        Assert.assertEquals(post.getId(), 1);
        Assert.assertNotNull(post.getTitle(), "Title should not be null");
    }

    @Test(description = "Validate POST request for creating a new post")
    public void testPostCreatePost() {
        Specification.installSpecification(Specification.requestSpecification(""),
                Specification.responseSpecification(201));

        CreatePost newPost = new CreatePost();
        newPost.setTitle("foo");
        newPost.setBody("bar");
        newPost.setUserId(1);

        Response response = given()
                .contentType("application/json")
                .body(newPost)
                .post("/posts");

        Assert.assertEquals(response.getStatusCode(), 201);

        Assert.assertTrue(response.getBody().asString().contains("id"));
    }
}
