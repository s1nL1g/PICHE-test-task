package tests.api.pojo;

import lombok.Data;

@Data
public class CreatePost {
    private String title;
    private String body;
    private int userId;
}
